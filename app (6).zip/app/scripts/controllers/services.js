'use strict';

/**
 * @ngdoc function
 * @name lebanseApp.controller:ServicesCtrl
 * @description
 * # ServicesCtrl
 * Controller of the lebanseApp
 */
angular.module('lebanseApp')
  .controller('ServicesCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
