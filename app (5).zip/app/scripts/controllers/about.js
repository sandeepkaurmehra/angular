'use strict';

/**
 * @ngdoc function
 * @name lebanseApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the lebanseApp
 */
angular.module('lebanseApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
